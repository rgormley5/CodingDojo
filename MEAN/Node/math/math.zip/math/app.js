var mathlibs = require('./mathlibs')();
console.log(mathlibs);
mathlibs.add(5,6);
mathlibs.multiply(5,6);
mathlibs.square(5);
mathlibs.random(5,60);