// Basic 1
// var x = []
// x.push('coding', 'dojo', 'rocks')
// x.pop()
// console.log(x)

// Basic 2
// const y = []
// y.push(88)
// console.log(y)

// Basic 3
// let z = [9, 10, 6, 5, -1, 20, 13, 2]
// for (i = 0; i < z.length; i++) {
//     console.log(z[i])
// }

// Basic 4
// let names = ['Kadie', 'Joe', 'Fritz', 'Pierre', 'Alphonso']
// for (i = 0; i < names.length; i++){
//     var x = names[i].length;
//     if (x >= 5) {
//         console.log(names[i]);
//     }
// }

// Basic 5
function yell(string){
    var x = string.toUpperCase();
    console.log(x)
    return x
}
yell("hi")
