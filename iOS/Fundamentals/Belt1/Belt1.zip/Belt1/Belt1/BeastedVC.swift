//
//  BeastedVC.swift
//  Belt1
//
//  Created by Robert Gormley on 3/23/18.
//  Copyright © 2018 Robert Gormley. All rights reserved.
//

import UIKit
import CoreData

class BeastedVC: UITableViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "Beasted"
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    

}
