//
//  File.swift
//  belt2
//
//  Created by Robert Gormley on 3/27/18.
//  Copyright © 2018 Robert Gormley. All rights reserved.
//

import Foundation

protocol ViewContactDelegate: class {
    func doneButtonTapped()
}
